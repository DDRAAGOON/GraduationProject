import 'package:flutter/material.dart';
import '../../../constants/app_images.dart';
import '../../../shared/l10n/app_localizations.dart';
import '../../../shared/state/recruitment_sync_store.dart';
import 'chat_thread_screen.dart';
import 'new_chat_screen.dart';

import '../../../shared/services/chat_service.dart';
import '../../../data/api/api_client.dart';

class MessagesListScreen extends StatefulWidget {
  const MessagesListScreen({super.key});

  @override
  State<MessagesListScreen> createState() => _MessagesListScreenState();
}

class _MessagesListScreenState extends State<MessagesListScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _searchQuery = "";
  List<Map<String, dynamic>> _rooms = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadRooms();
    _searchController.addListener(() {
      setState(() => _searchQuery = _searchController.text.toLowerCase());
    });
  }

  Future<void> _loadRooms() async {
    setState(() => _isLoading = true);
    final rooms = await ChatService.instance.getChatRooms();
    setState(() {
      _rooms = rooms;
      _isLoading = false;
    });
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final t = AppLocalizations.of(context);
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final backgroundColor = isDark ? const Color(0xFF001E3A) : const Color(0xFFF8FBF4);
    final onSurfaceColor = isDark ? Colors.white : Colors.black;

    return Scaffold(
      backgroundColor: backgroundColor,
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => const NewChatScreen()),
        ),
        backgroundColor: const Color(0xFFDDE6FF),
        elevation: 4,
        child: const Icon(Icons.add, color: Color(0xFF011931)),
      ),
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: _loadRooms,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 10),
                Text(
                  t.messages,
                  style: TextStyle(
                    color: onSurfaceColor,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 15),
                _buildSearchBar(context, t, isDark, onSurfaceColor),
                const SizedBox(height: 20),
                Expanded(
                  child: _isLoading 
                    ? const Center(child: CircularProgressIndicator())
                    : _rooms.isEmpty
                      ? _buildEmptyState(t, onSurfaceColor)
                      : ListView.separated(
                          physics: const AlwaysScrollableScrollPhysics(),
                          itemCount: _rooms.length,
                          separatorBuilder: (context, index) => Divider(
                            color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.12),
                            height: 1,
                          ),
                          itemBuilder: (context, index) {
                            final room = _rooms[index];
                            final participants = room['participants'] as List? ?? [];
                            // البحث عن الطرف التاني (الشركة)
                            // المفروض السيرفر بيبعت بيانات الطرف التاني بشكل مباشر أو بنفلترها
                            final otherUser = participants.isNotEmpty ? participants[0] : null; 
                            
                            final name = otherUser?['fullName'] ?? otherUser?['name'] ?? "Chat Room";
                            final lastMsg = room['lastMessage']?['text'] ?? room['lastMessage']?['content'] ?? "";
                            final image = ApiClient.resolveImageUrl(otherUser?['avatar'] ?? otherUser?['photoUrl'] ?? "");
                            final roomId = room['_id'] ?? room['id'];

                            return _buildMessageItem(
                              context,
                              name: name,
                              message: lastMsg,
                              time: "", // ممكن تحويل وقت آخر رسالة لو موجود
                              image: image,
                              roomId: roomId,
                              onSurfaceColor: onSurfaceColor,
                            );
                          },
                        ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState(AppLocalizations t, Color onSurfaceColor) {
    return SingleChildScrollView(
      physics: const AlwaysScrollableScrollPhysics(),
      child: SizedBox(
        height: MediaQuery.of(context).size.height * 0.6,
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.chat_bubble_outline, size: 64, color: onSurfaceColor.withValues(alpha: 0.2)),
              const SizedBox(height: 16),
              Text(
                t.tr(en: "No messages yet", ar: "لا توجد رسائل بعد"),
                style: TextStyle(
                  color: onSurfaceColor.withValues(alpha: 0.54),
                  fontSize: 16,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSearchBar(BuildContext context, AppLocalizations t, bool isDark, Color onSurfaceColor) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: isDark
            ? Colors.white.withValues(alpha: 0.05)
            : Colors.black.withValues(alpha: 0.05),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: (isDark ? Colors.white : Colors.black).withValues(alpha: 0.12)),
      ),
      child: TextField(
        controller: _searchController,
        style: TextStyle(color: onSurfaceColor),
        decoration: InputDecoration(
          icon: Icon(Icons.search, color: onSurfaceColor.withValues(alpha: 0.54)),
          hintText: t.tr(en: "Search messages", ar: "البحث في الرسائل"),
          hintStyle: TextStyle(color: onSurfaceColor.withValues(alpha: 0.38)),
          border: InputBorder.none,
        ),
      ),
    );
  }

  Widget _buildMessageItem(
    BuildContext context, {
    required String name,
    required String message,
    required String time,
    required String image,
    required String roomId,
    required Color onSurfaceColor,
  }) {
    return InkWell(
      onTap: () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => ChatThreadScreen(
            name: name, 
            image: image,
            roomId: roomId, // هنعدل ChatThreadScreen لاستقبال roomId
          ),
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 12),
        child: Row(
          children: [
            CircleAvatar(
              radius: 28, 
              backgroundImage: image.startsWith('http') 
                ? NetworkImage(image) 
                : AssetImage(image.isEmpty ? AppImages.companyProfile2 : image) as ImageProvider
            ),
            const SizedBox(width: 15),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(name, style: TextStyle(
                        color: onSurfaceColor,
                        fontSize: 16, 
                        fontWeight: FontWeight.bold
                      )),
                      Text(time, style: TextStyle(
                        color: onSurfaceColor.withValues(alpha: 0.38), 
                        fontSize: 12
                      )),
                    ],
                  ),
                  const SizedBox(height: 5),
                  Text(
                    message,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: onSurfaceColor.withValues(alpha: 0.54),
                      fontSize: 14
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
